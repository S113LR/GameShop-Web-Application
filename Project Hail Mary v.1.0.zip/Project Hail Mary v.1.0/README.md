# NinExpo eShop

NinExpo eShop is a browser-only storefront preview. Account information and order records are saved in the current browser. The site is not connected to an online account service or payment processor.

## Run the storefront

Serve this folder from a local web server, then open the page in your browser. For example, with Visual Studio Code, use the Live Server extension and open `index.html`. You can also use any static HTTP server. No backend, environment variables, database, or email service is required.

## Accounts and data

- Create an account with an email address and profile details. No password is requested, no email is sent, and the email address is not verified.
- Signing in with an existing account email opens that local account. Anyone who can use this browser profile can sign in by entering its email.
- The current login session, account profile, compressed avatar, cart, currency preference, and order history are stored in this browser's `localStorage`.
- Data is limited to this browser profile on this device. It is not encrypted, backed up, shared across devices, or recoverable if browser data is cleared.
- Do not enter real payment details or sensitive personal information. Checkout saves an order simulation and estimated delivery; it does not charge a payment method, issue a game key, arrange a shipment, or send email.
- Browser storage has a size limit. Avatar photos are resized and compressed before saving; if storage still fills up, remove the photo or clear this site's data.

To remove locally saved accounts and orders, clear this site's browser storage using the browser's site-data settings or developer tools. This deletes all accounts, sessions, carts, profiles, and order history saved by the site.
